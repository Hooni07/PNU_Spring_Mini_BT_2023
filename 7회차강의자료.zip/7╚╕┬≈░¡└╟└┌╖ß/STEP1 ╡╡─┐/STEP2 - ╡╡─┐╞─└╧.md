# STEP2 - 도커파일

> Docker는 지정된 이미지를 빌드하는 데 필요한 모든 명령이 순서대로 포함된 텍스트 파일인 Dockerfile의 지침을 읽어 이미지를 자동으로 빌드합니다. [Dockerfile은 Dockerfile 참조](https://docs.docker.com/engine/reference/builder/) 에서 찾을 수 있는 특정 형식과 지침 세트를 준수합니다 .



**예시**

```dockerfile
FROM ubuntu:22.04
COPY . /app
RUN make /app
ENTRYPOINT ["python", "/app/app.py"]
```

- `FROM`Docker 이미지 에서 레이어를 생성합니다 `ubuntu:22.04`.
- `COPY`Docker 클라이언트의 현재 디렉터리에서 파일을 추가합니다.
- `RUN`를 사용하여 애플리케이션을 빌드합니다 `make`.
- `ENTRYPOINT`컨테이너가 시작될 때 실행할 명령을 지정합니다.



## RUN

`RUN`Dockerfile을 더 읽기 쉽고, 이해하기 쉽고, 유지 관리하기 쉽게 만들기 위해 길거나 복잡한 명령문을 백슬래시로 구분된 여러 줄로 분할하세요 .

```dockerfile
RUN apt-get update && apt-get install -y \
    package-bar \
    package-baz \
    package-foo  \
    && rm -rf /var/lib/apt/lists/*
```



**RUN  오래된 버전 캐싱**

```dockerfile
FROM ubuntu:22.04
RUN apt-get update
RUN apt-get install -y curl nginx
```

Docker는 초기 지침과 수정된 지침을 동일하게 보고 이전 단계의 캐시를 재사용합니다. `apt-get update`실행된 후에 캐시된 결과로 install이 수행되기 때문에 잠재적으로 `curl`및 `nginx`패키지의 오래된 버전을 얻을 수 있습니다.

`RUN apt-get update && apt-get install -y`를 사용하면 추가 코딩이나 수동 개입 없이 Dockerfile이 최신 패키지 버전을 설치할 수 있습니다. 이 기술을 캐시 무효화라고 합니다. 

```dockerfile
RUN apt-get update && apt-get install -y \
    package-bar \
    package-baz \
    package-foo=1.3.*
```



## ENV

아래의 환경변수를 설정하면 MYSQL 디비가 생성될 때 초기값이 세팅된다. 

```doc
FROM mysql:5.7

ENV MYSQL_USER=cos
ENV MYSQL_PASSWORD=cos1234
ENV MYSQL_ROOT_PASSWORD=root1234
ENV MYSQL_DATABASE=cosdb
```

![image-20231125034426417](images/image-20231125034426417.png)

https://hub.docker.com/_/mysql



## ENTRYPOINT

> Entrypoint에는 반드시 실행되야 하는 명령을 넣는다.

```doc
FROM httpd:alpine

COPY ./apache2/htdocs /usr/local/apache2/htdocs
ENTRYPOINT ["/bin/echo", "hello"]
```



## WORKDIR

> RUN, CMD, ENTRYPOINT 명령이 실행될 디렉토리를 설정할 수 있다. bin/bash로 최초 접속시 접속되는 폴더 또한 WORKDIR로 지정된다

```dock
FROM httpd:alpine

WORKDIR /usr/local/apache2/htdocs

CMD ["/bin/cat", "index.html"]
```



## EXPOSE

>  docker 컨테이너의 특정 포트를 외부에 오픈하는 설정
>
>  docker run -p 옵션은 포트포워딩할 때 사용하는 것이고 EXPOSE는 해당 도커파일로 이미지를 빌드하여 컨테이너를 생성하면 80 포트가 열려있다고 문서에 명시에 주는 개념...안해도 상관없음.

```dock
FROM ubuntu:18.04
LABEL maintainer="getinthere@naver.com"

RUN apt-get update
RUN apt-get install -y apache2

EXPOSE 80
COPY ./airbnb /var/www/html/

ENTRYPOINT ["/usr/sbin/apache2ctl", "-D", "FOREGROUND"]
```



## Docker run -v 옵션 && Dockerfile copy와 volume

**docker run -v 옵션**

> 호스트의 특정 폴더 혹은 파일을 Container에서 참조해서 사용

![image-20231125035121126](images/image-20231125035121126.png)



**COPY**

> 호스트의 특정 폴더 혹은 파일을 Container에서 복사해서 사용

![image-20231125035253885](images/image-20231125035253885.png)

**docker file에서 volume 설정**

> 도커 볼룜 저장소 연결

![image-20231125040109653](images/image-20231125040109653.png)