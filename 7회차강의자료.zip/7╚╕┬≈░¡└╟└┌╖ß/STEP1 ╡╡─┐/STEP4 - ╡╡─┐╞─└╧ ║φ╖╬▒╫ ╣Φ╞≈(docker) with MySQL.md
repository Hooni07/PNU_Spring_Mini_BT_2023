# STEP4 - 도커파일 블로그 배포(docker) with MySQL

## 1. Dockerfile 작성

아래 URL을 다운 받아서 실습을 시작하세요.

https://github.com/busanuv/docker-server-test.git

![image-20231125042030403](images/image-20231125042030403.png)

> ubuntu를 빌드하여, git, jdk, mysql을 설치한다.
>
> 환경변수를 등록해둔다. 도커 컨테이너에 환경변수가 5개가 등록된다.
>
> 호스트 환경에  init.sql을 도커 컨테이너에 복사한다.
>
> 나머지는 동일하다.

```dock
FROM ubuntu

RUN apt-get update && apt-get install -y git openjdk-11-jdk mysql-server

ENV RDS_HOSTNAME=localhost
ENV RDS_PORT=3306
ENV RDS_DB_NAME=blogdb
ENV RDS_USERNAME=ssar
ENV RDS_PASSWORD=ssar1234

WORKDIR /home/ubuntu/

COPY  ./init.sql ./init.sql
COPY ./entrypoint.sh ./entrypoint.sh

RUN ["chmod", "+x", "entrypoint.sh"]
ENTRYPOINT ["/bin/bash", "./entrypoint.sh"]

EXPOSE 3306
EXPOSE 8080
```



## 2. init.sql 작성

```sql
CREATE TABLE IF NOT EXISTS user_tb (
    id integer auto_increment,
    created_at timestamp,
    email varchar(20) not null,
    password varchar(60) not null,
    username varchar(20) not null unique,
    profile varchar(100),
    primary key (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS board_tb (
    id integer auto_increment,
    content varchar(10000),
    created_at timestamp,
    title varchar(100) not null,
    user_id integer,
    primary key (id),
    constraint fk_board_user_id foreign key (user_id) references user_tb (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS reply_tb (
    id integer auto_increment,
    comment varchar(100) not null,
    created_at timestamp,
    board_id integer,
    user_id integer,
    primary key (id),
    constraint fk_reply_board_id foreign key (board_id) references board_tb (id),
    constraint fk_reply_user_id foreign key (user_id) references user_tb (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

FLUSH PRIVILEGES;
```



## 3. entrypoint.sh 작성

> docker 모드로 스프링을 실행한다.

```sh
service mysql start
mysql -u root <<<"CREATE DATABASE IF NOT EXISTS $RDS_DB_NAME ;"
mysql -u root <<<"CREATE USER IF NOT EXISTS $RDS_USERNAME IDENTIFIED BY '$RDS_PASSWORD' ;"
mysql -u root <<<"GRANT ALL PRIVILEGES ON $RDS_DB_NAME.* TO $RDS_USERNAME ;"
mysql -u root $RDS_DB_NAME < init.sql

git clone https://github.com/busanuv/blog-last.git
cd blog-last
chmod +x gradlew
./gradlew build
java -jar -Dspring.profiles.active=docker build/libs/*.jar
```



## Here String Operator

이 연산자는 문자열을 명령어에 직접 입력하는 데 사용됩니다. 예시에서는 mysql 명령어와 함께 사용되어 셸에서 직접 SQL 명령을 제공합니다.

```shell
mysql -u root <<< "CREATE DATABASE IF NOT EXISTS $RDS_DB_NAME ;"
```


## Here Document

Here Document는 여러 줄의 텍스트를 명령어에 전달하는 데 사용됩니다. 다음은 여러 줄의 텍스트를 mysql 명령에 전달하는 예시입니다.

```shell
mysql -u root << EOF
CREATE DATABASE IF NOT EXISTS $RDS_DB_NAME ;
CREATE USER IF NOT EXISTS $RDS_USERNAME IDENTIFIED BY '$RDS_PASSWORD' ;
GRANT ALL PRIVILEGES ON $RDS_DB_NAME.* TO $RDS_USERNAME ;
EOF
```

```txt
EOF는 Here Document라고 불리는 구문으로, 셸 스크립트에서 여러 줄의 텍스트를 입력 또는 명령에 전달할 때 사용됩니다. EOF는 End of File의 약자로, 
여기서는 특별한 종료 문자열로 사용됩니다. 여러 줄의 텍스트 블록을 << EOF와 EOF 사이에 위치시킴으로써 해당 블록의 내용을 명령어에 전달할 수 있습니다.
```

## Input Redirection

이 연산자는 파일에서 입력을 읽어와 명령어에 전달하는 데 사용됩니다. 예시에서는 init.sql 파일의 내용을 mysql 명령으로 전달합니다.

```shell
mysql -u root $RDS_DB_NAME < init.sql
```



## 4. Dockerfile 실행

```
docker build -t step2 . && docker run -p 8080:8080 -p 3306:3306 -it step2
```

