# STEP3 - 도커파일 블로그 배포(dev) 테스트

| FROM       | 베이스 이미지 지정  ex) FROM httpd:alpine                    |
| ---------- | ------------------------------------------------------------ |
| LABEL      | 버전 정보                                                    |
| CMD        | docker container가 시작될 때 실행되는 쉘 명령. 단 하나의 CMD 명령만 사용가능ex) CMD ["node", "test.js"]Entrypoint가 컨테이너 실행시 무조건 실행되는 명령어라면CMD는 컨테이너 실행시 Entrypoint의 옵션이 되기도 하고,다른 명령어로 실행해야 될 수 도 있을 때는 Entrypoint 대신 사용하여 동적으로 실행 명령어를 전달할 수 있게 된다. run 명령어 가장 마지막에 추가되는 것 또한 CMD이기 때문이다. |
| RUN        | 이미지 작성시 실행되는 쉘 명령. 여러개의 RUN 명령 사용가능ex) RUN apt-get -y install vim |
| ENTRYPOINT | docker container가 시작할 때 실행되는 쉘 명령.* docker run 명령어 젤 끝에 명령어를 추가해도 ENTRYPOINT 명령이 무조건 실행됨* CMD 는 docker run 명령어 젤 끝에 명령어를 추가하면 CMD 명령이 무시됨 |
| EXPOSE     | docker 컨테이너 외부에 오픈할 포트 설정ex) EXPOSE 8080docker run -p 80:8080 ubuntu위와 같이 요청이 되면 내부 컨테이너에서 8080포트가 열려있어야 하는데 그걸 여는 명령어가 EXPOSE임 |
| ENV        | docker container 내부에서 사용할 환경 변수 지정ex) ENV PATH /usr/bin:$PATH기존 리눅스 환경변수 지정 명령과 조금 다름.ex) export PATH=/usr/bin:$PATH |
| WORKDIR    | docker container 가 시작될 때 시작되는 폴더 설정 (작업 디렉토리 설정)ex) 해당 컨테이너에 접속하면 최초로 접속될 폴더 설정을 의미함 |
| COPY       | 파일 또는 디렉토리를 docker container에 복사할 때 사용ex) COPY app.py /home/ubuntu/app.py[참고]docker run -v 옵션은 호스트의 데이터를 docker container에 공유할 때 사용하는 것. |
| ADD        | COPY 명령과 똑같은데 다른 점은 압축파일을 복사하면 자동으로 압축이 풀린다는 장점이 있다. deploy.zip 파일을 던질때 사용 |
| VOLUME     | 도커 컨테이너 내부의 특정 폴더는 도커 컨테이너가 stop 되면 데이터가 유실된다.그렇기 때문에 도커 컨테이너의 특정 폴더를 도커가 관리하는 외부 볼륨으로 연결하여 파일을 관리하는 명령을 사용하면 좋다도커를 사용하여 DB 데이터를 관리할 때, 볼륨(Volume)을 사용하는 것이 좋습니다. 볼륨은 도커 컨테이너의 파일 시스템에서 호스트 파일 시스템으로 데이터를 분리하고 관리하는 방법입니다.볼륨을 사용하면 여러 가지 이점이 있습니다:데이터 지속성(Persistence): 컨테이너가 삭제되거나 업데이트 되더라도 볼륨에 저장된 데이터는 유지됩니다. 이를 통해 데이터 손실을 방지할 수 있습니다.백업 및 마이그레이션: 볼륨을 사용하면 호스트 시스템에서 데이터 백업이나 다른 시스템으로의 데이터 이전이 쉬워집니다.성능: 볼륨은 도커 컨테이너의 파일 시스템 성능을 향상시키며, 호스트 파일 시스템과 도커 컨테이너의 파일 시스템 간의 성능 저하를 최소화합니다.데이터 공유: 여러 컨테이너 간에 볼륨을 공유할 수 있어, 서로 다른 컨테이너에서 동일한 데이터를 사용할 수 있습니다. |



## 1. Dockerfile 작성

아래 URL을 다운 받아서 실습을 시작하세요.

https://github.com/busanuv/docker-server-test.git

![image-20231125040838274](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231125040838274.png)

**Dockerfile**

> ubuntu 이미지를 도커 허브에서 가져온다
>
> RUN을 이용하여 APT를 update한 뒤 프로그램을 설치한다.
>
> 작업 디렉토리를 사용자 홈폴더로 설정한다.
>
> 호스트의 파일을 도커 컨테이너로 COPY한다.
>
> RUN을 이용하여 entrypoint.sh 파일에 실행 권한을 준다.
>
> ENTRYPOINT를 이용하여 최종 실행한다.

```doc
FROM ubuntu

RUN apt-get update && apt-get install -y git openjdk-11-jdk

WORKDIR /home/ubuntu/

COPY ./entrypoint.sh ./entrypoint.sh
RUN ["chmod", "+x", "entrypoint.sh"]
ENTRYPOINT ["/bin/bash", "./entrypoint.sh"]

EXPOSE 8080
```



**entrypoint.sh**

> git에서 프로젝트를 다운받은 뒤 gradlew에 실행권한을 주고 빌드한다
>
> prod 모드로 spirng을 실행한다.

```sh
git clone https://github.com/busanuv/blog-last.git
cd blog-last
chmod +x gradlew
./gradlew build
java -jar -Dspring.profiles.active=dev build/libs/*.jar
```



## 2. Dockerfile 실행

> docker build 명령어로 빌드한다. 빌드하면 도커 이미지가 만들어진다.
>
> -t 태그 옵션을 줘서 이미지 태그명을 step1으로 잡는다.
>
> build시에는 Dockerfile에 있는 위치에서 하면 . 을 사용해서 빌드할 수 있다.
>
> Dockerfile명이 DockerHello 라면 docker build -t step1 DockerHello 라고 명령어를 실행해야 한다.
>
> build된 이미지 태그명으로 이어서 docker run을 한다.

```
docker build -t step1 . && docker run -p 8080:8080 -it step1
```



-it 를 빼고 실행해도 된다. 하지만 -it를 주면 터미널모드로 실행하게 되어서 예쁜 로그를 볼 수 있다.

![image-20231125041753074](images/image-20231125041753074.png)

-it 옵션을 주지 않고 실행했을 때

![image-20231125041801602](images/image-20231125041801602.png)