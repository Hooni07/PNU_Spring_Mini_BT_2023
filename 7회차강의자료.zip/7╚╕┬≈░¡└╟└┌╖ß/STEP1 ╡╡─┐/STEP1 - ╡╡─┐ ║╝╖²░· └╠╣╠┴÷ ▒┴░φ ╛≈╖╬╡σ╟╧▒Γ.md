# STEP1 - 도커 볼륨과 이미지 굽고 업로드하기



## 1. 도커 볼륨 연결하기

> 호스트 시스템의 파일을 도커 컨테이너가 참조할 수 있게 설정하는 방법 (소프트 링크 방식 == 윈도우 바로가기)

```
docker run -d -p 80:80 -v c:\users\ssarm\webapps:/usr/local/apache2/htdocs httpd
```



![image-20231118013752083](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231118013752083.png)

```html
<html>
<body>
    <h1>안녕 볼륨 연결을 해뒀어!!</h1>
</body>
</html>
```

![image-20231118013817690](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231118013817690.png)

## 2. 현재 이미지 상태 빌드하기

### 2.1 도커 허브 레포 만들기

> ![image-20231118014034413](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231118014034413.png)

![image-20231118014012819](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231118014012819.png)

### 2.2 빌드하기

```
docker commit 컨테이너ID 도커허브아이디/레포이름:버전
```

![image-20231118014219675](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231118014219675.png)

```
docker commit 1d3a codingspecialist/metacoding-httpd:1.0
```



```
docker images
```

![image-20231118014417530](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231118014417530.png)



### 2.3 도커 허브에 푸시하기

```
docker push codingspecialist/metacoding-httpd:1.0
```

![image-20231118014544476](C:\Users\ssarm\AppData\Roaming\Typora\typora-user-images\image-20231118014544476.png)



# 3. 블로그 프로젝트 도커 환경에서 테스트 해보기

- ubuntu 환경 pull 받기
- JDK 11 설치
- git clone
- jar 파일 빌드 (dev 모드로 테스트 됨)
- MySQL 설치
- 데이터베이스 생성
- 테이블 세팅
- jar 파일 application-docker.yml 프로파일로 실행 (MySQL 설치 필요)
- 로그 확인
- 디버깅 및 테스트

위와 같은 과정들이 필요한데, 이를 위해서 Dockerfile과 리눅스 명령어 학습이 필요하다. 다음 시간에 AWS 회원가입 후 리눅스 명령어에 대한 모든 학습을 마치면 위 테스트를 로컬 컴퓨터에서 도커로 해볼 수 있다.