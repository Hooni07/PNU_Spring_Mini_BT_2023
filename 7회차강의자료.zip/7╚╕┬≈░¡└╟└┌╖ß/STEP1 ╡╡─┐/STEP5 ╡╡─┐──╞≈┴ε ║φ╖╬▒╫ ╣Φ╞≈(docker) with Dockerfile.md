# STEP5 도커컴포즈 블로그 배포(docker) with Dockerfile

## 1. DockerCompose란

> Docker Compose란 여러 컨테이너를 가지는 애플리케이션을 통합적으로 만들고, 각각의 컨테이너를 시작 및 중지하는 작업을 더 쉽게 수행할 수 있도록 도와주는 도구
>
> 배포직전에 로컬에서 여러 컨테이너를 배포 환경과 동일하게 테스트해보기 위해 사용
>
> 실제 배포시에는 DockerCompose를 사용하지 않음.
>
> 배포시에는 여러 Dockerfile을 배포할 때 도와주는 쿠버네티스나 AWS의 ECS를 사용



![image-20231125042805106](images/image-20231125042805106.png)

- image
  - image는 해당 서비스에서 사용할 도커 이미지 이름을 정의합니다. 이 이미지는 Docker Hub, Private Registry 또는 로컬에 저장되어 있을 수 있습니다.
  - image를 사용하면 해당 서비스는 이미지를 이미 가지고 있으므로 Dockerfile을 사용하여 이미지를 빌드할 필요가 없습니다. 이미지가 로컬 또는 리모트 레지스트리에서 가져올 수 있습니다.
- continer_name
  - container_name은 컨테이너의 이름을 정의합니다. 이름을 지정하지 않으면 Docker Compose는 자동으로 이름을 생성합니다.

- ports
  - ports는 컨테이너가 사용할 포트와 호스트에서 사용할 포트를 지정합니다.
- environment
  - environment는 서비스에서 사용할 환경 변수를 정의합니다.
- volumes
  - volumes는 컨테이너와 호스트 간의 데이터 공유를 위한 볼륨을 정의합니다.
- depends_on
  - depends_on은 다른 서비스에 의존하는 서비스를 정의합니다.
- build
  - build는 Dockerfile을 사용하여 이미지를 빌드합니다.
  - Dockerfile을 사용하여 새로운 이미지를 빌드합니다. build는 image와 다르게 이미지를 이미 가지고 있지 않습니다. 따라서 이미지를 빌드하기 위해 Dockerfile을 사용하며, 이미지를 로컬 또는 리모트 레지스트리에 저장할 수 있습니다.
  - context 설정을 통해 특정 폴더의 Dockerfile을 빌드할 수 있습니다.



## 2. DockerCompose 사용팁

도커 컴포즈에서 수많은 기능을 제공해줍니다. 하지만 실제 배포에서는 Dockerfile을 사용하기 때문에 Dockerfile에서 작성할 수 있는 문법은 Dockerfile로 작성하고, 여러개의 Dockerfile을 묶는 용도로만 DockerCompose를 사용하는 것을 추천드립니다.



## 3. 환경변수 사용팁

환경변수는 Dockerfile에서도 작성할 수 있고, DockerCompose에서도 사용할 수 있습니다.

어디에 작성을 해야할까요?



**Dockerfile 환경변수**

Docker Image를 배포하는 도커 허브에 문서를 읽어보면 특정 환경변수를 설정해두면, 본인들이 이미지를 생성할 때 해당 환경변수를 사용하여 생성하겠다는 문서를 볼 수 있습니다. 이럴때 Dockerfile에 환경변수를 설정합니다.

![image-20231125043343226](images/image-20231125043343226.png)



**예시**

![image-20231125043738314](images/image-20231125043738314.png)





**DockerCompose 환경변수**

여러 컨테이너가 통신을 해야할 때, 스프링에서 MYSQL의 ip가 동적으로 만들어지기 때문에 미리 확인을 할 수 없을 때가 있습니다. 이때 도커 컴포즈로 만들어지는 모든 컨테이너는 서비스명으로 통신을 할 수 있게 됩니다. 해당 서비스명을 사용해서 환경변수를 만들어두면 DockerCompose로 컨테이너를 생성하는 동안 서비스명이 ip주소로 자동 치환되게 됩니다.



**예시**

![image-20231125043800097](images/image-20231125043800097.png)

## 4. 도커컴포즈로 MySQL과 Spring 연결해서 실행하기

아래 URL을 다운 받아서 실습을 시작하세요.

https://github.com/busanuv/docker-server-test.git